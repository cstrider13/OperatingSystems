How I built my solution: I went to lab1/os and typed "make". Then I went to lab1/apps and typed "make". Then I typed "dlxsim -x /lab1/os/work/os.dlx.obj -a -u /lab1/apps/work/userprog.dlx.obj". Depending on how the files are organized for you, more information before /lab1 may need to be added. 
My main function calls the getpid function and returns the current id once whenthe main function is run.

External sources: I read Piazza posts. I went to lab hours to ask if my code was properly set up. I would google errors every so often. I used an online c compiler called "onlinegdb.com/online_c_compiler" to test out how I should work with currentPCB and pcbs.
