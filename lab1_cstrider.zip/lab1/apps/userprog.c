#include "usertraps.h"

void main (int x)
{
  unsigned int index = 0;
  Printf("Hello World!\n");
  index = Getpid();
  Printf("Index(userprog.c) = %d\n", index);
  while(1); // Use CTRL-C to exit the simulator
}
